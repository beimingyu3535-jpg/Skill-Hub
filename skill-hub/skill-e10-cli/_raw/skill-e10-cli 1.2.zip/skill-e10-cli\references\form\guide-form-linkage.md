# 表单字段显隐联动指南

## 概述

字段显隐联动：当某些字段的值满足条件时，自动改变其他字段的显示属性（隐藏/显示/编辑/只读/必填）。

## CLI 命令

```bash
e10-cli form linkage add <appId> <objId> <name> --config @<json文件>
```

## 配置 JSON 格式

```json
{
  "conditions": [
    {
      "fieldId": "触发字段ID",
      "operator": "EQUAL",
      "options": [{"optionId": "选项ID", "content": "选项名"}]
    }
  ],
  "actions": [
    {
      "prop": "hide",
      "fields": [
        {
          "fieldId": "目标字段ID",
          "name": "字段名称",
          "dataKey": "字段编码",
          "fieldType": "Employee"
        }
      ]
    }
  ]
}
```

### conditions（触发条件）

多个条件之间是 **AND** 关系（全部满足才触发）。

| 字段 | 说明 |
|------|------|
| fieldId | 触发字段的 fieldId（从 `form read --app-id` 获取） |
| operator | 比较符：`EQUAL`（等于）、`NOT_EQUAL`（不等于）、`CONTAIN`（包含）、`NOT_CONTAIN`（不包含） |
| value | 普通字段的比较值（文本/数字） |
| options | Select/RadioBox 字段的选项，格式：`[{"optionId": "选项ID", "content": "选项名"}]` |

### actions（联动效果）

| 属性 | prop 值 | 效果 |
|------|---------|------|
| 隐藏 | `hide` | 字段隐藏不可见 |
| 隐藏行 | `hideRow` | 字段所在行整行隐藏（仅表格布局） |
| 显示（只读） | `show` | 字段显示但不可编辑 |
| 编辑 | `edit` | 字段显示且可编辑 |
| 只读 | `readonly` | 字段显示且不可编辑（同 show） |

> ⚠️ **`required` 不支持**：`prop:required` 联动会触发平台后端 NPE（实测不可用），CLI 已拦截报错。要"条件必填"请改用 `readonly`/`hide`，或在前端设计器里配置必填联动。

**优先级**：`hide` > `readonly` > `edit`

多个联动规则同时满足时，优先级高的生效。

## 示例

### 示例 1：优先级=高 时隐藏负责人字段

```json
{
  "conditions": [
    {
      "fieldId": "1290473132445114373",
      "operator": "EQUAL",
      "options": [{"optionId": "1290473132445114394", "content": "高"}]
    }
  ],
  "actions": [
    {
      "prop": "hide",
      "fields": [
        {
          "fieldId": "1290473132445114370",
          "name": "负责人",
          "dataKey": "fzr48cef",
          "fieldType": "Employee"
        }
      ]
    }
  ]
}
```

### 示例 2：金额 > 10000 时审批人变为只读

> `required` 联动平台会 NPE，改用 `readonly`（条件满足时审批人只读不可编辑）。

```json
{
  "conditions": [
    {
      "fieldId": "金额字段ID",
      "operator": "GREATER_THAN",
      "value": "10000"
    }
  ],
  "actions": [
    {
      "prop": "readonly",
      "fields": [
        {
          "fieldId": "审批人字段ID",
          "name": "审批人",
          "dataKey": "spr89abc",
          "fieldType": "Employee"
        }
      ]
    }
  ]
}
```

## 注意事项

1. **主表 vs 明细表**：主表触发字段可修改主表或明细字段；明细表触发字段只能修改本行字段
2. **表格布局限制**：通过隐藏行/列/单元格自定义属性隐藏的字段，无法通过联动显示出来
3. **明细表字段列隐藏**：需在明细表第一行配置操作按钮元素
4. **多规则冲突**：避免同一个触发字段或同一个目标字段出现在多个规则里
5. **默认属性**：字段的默认显示属性为设计器中设置的"读写属性"或"字段权限"
6. **目标字段 dataKey**：config 里目标字段需要 `dataKey`，但 `form read` 不返回这个字段——用 `fieldId` 代替可行（`dataKey` 留空或用 `fieldId` 均可）
7. **Select 选项 ID**：必须用 `form read --app-id` 返回的真实 `valueKey`（自动生成的长 ID，如 `1294601918674214939`），不能用建表单时给的短 `valueKey`（如 `"GQ"` / `"5"`）

---

## 值带出（编辑已有字段的 ffRelateField）

值带出不是 `linkage add` 的显隐规则，而是**字段级配置**（`ffRelateField`）：当 EBuilder 关联字段选中某条记录后，自动将该记录的某个字段值复制到当前字段。例如：选客户→自动带出联系人；选合同→自动带出合同金额。

### 创建时配置

`form create --fields` 里用 `relateFrom` 定义，CLI 在 create Step 3 自动配置 ffRelateField：

```json
{ "componentKey": "Text", "fieldName": "联系人",
  "relateFrom": { "ebuilderField": "关联客户", "sourceFieldId": "1296220571782152194" } }
```

### 创建后补配

```bash
e10-cli form edit-field <objId> <appId> <fieldId> \
  --relate-from <EBuilder字段名> \
  --relate-from-source <目标表单源字段fieldId>
```

> ⚠️ **`sourceFieldId` 和 `--relate-from-source` 必须传字段的数字 fieldId**（如 `1296220571782152194`），不能传字段名（如"联系人姓名"）。用 `form read <objId> --app-id <appId>` 获取字段的 fieldId。

- `--relate-from`：本表单中的 EBuilder 关联字段名（如 `"关联客户"`）
- `--relate-from-source`：关联目标表单中要复制值的字段 fieldId

### HRM 值带出（form relate，表内 Employee/Department 源）

换表内的**人员字段**或**部门字段**自动填目标字段。源字段是表单里的 Employee/Department 类型，目标字段按 HRM 属性带出值。实测结构差异：**Employee 源 ffRelateField 带 `module:"hrm"`，Department 源不带**。

```bash
# 换「申请人」(Employee) → 自动填「申请人工号」为邮箱
e10-cli form relate <appId> <objId> 申请人工号 --from 申请人 --key email

# 换「所属部门」(Department) → 自动填「申请人工号」为部门编号
e10-cli form relate <appId> <objId> 申请人工号 --from 所属部门 --key code
```

参数：
| 参数 | 说明 |
|------|------|
| `<targetField>` | 目标字段（被填充），名称或 fieldId |
| `--from <field>` | 源字段（触发），必须 Employee 或 Department 类型 |
| `--key <key>` | 带出属性 key。默认 Employee=`department`、Department=`name`。不传 `--title` 时自动取属性中文名 |

`--key` 从平台清单校验（`listBusinessField`），非法 key 会报错并列出可选属性：

**Employee 源**（人员属性，部分）：`username`姓名 / `email`邮箱 / `superior`上级 / `mobile`手机 / `jobNum`工号 / `hiredate`入职时间 / `department`部门 / `position`岗位 / `grade`职级 / `allSuperiors`所有上级 …

**Department 源**（部门属性，全部）：`name`部门名称(→Text) / `code`部门编号(→Text) / `parent`上级部门(→Department) / `fullname`部门全称(→Text) / `department.coadjutant`协办人(→RelateBrowser) / `deptEmployee`部门人员(→Employee)

> 目标字段类型与属性不匹配时命令只提示警告、不阻止（如 `deptEmployee` 通常只能填 Employee 字段）。
